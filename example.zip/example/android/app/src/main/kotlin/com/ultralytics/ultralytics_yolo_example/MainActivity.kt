package com.ultralytics.ultralytics_yolo_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
