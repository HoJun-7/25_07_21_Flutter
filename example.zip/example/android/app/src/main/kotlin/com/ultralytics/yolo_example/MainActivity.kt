// Ultralytics 🚀 AGPL-3.0 License - https://ultralytics.com/license

package com.ultralytics.yolo_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
